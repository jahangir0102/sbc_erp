import frappe
from frappe.model.document import Document


class WhatsAppRecipient(Document):
	pass