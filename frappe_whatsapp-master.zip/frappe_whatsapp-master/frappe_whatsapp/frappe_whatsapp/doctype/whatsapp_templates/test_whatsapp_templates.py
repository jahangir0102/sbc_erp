# Copyright (c) 2022, Shridhar Patil and Contributors
# See license.txt

# import frappe
from frappe.tests import UnitTestCase


class TestWhatsAppTemplates(UnitTestCase):
	pass
